'use strict';

angular.module('todoListApp', ['ngResource']);
